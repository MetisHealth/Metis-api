package com.yigitcolakoglu.Clinic;

public class InvalidAppointmentException extends Exception { 
    public InvalidAppointmentException(String errorMessage) {
                    super(errorMessage);
                            
    }
        
}
